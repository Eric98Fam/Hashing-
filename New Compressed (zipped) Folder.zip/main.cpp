#include<iostream>
#include <fstream>
#include <string>
#include <cmath>
using namespace std;

class Customer {
private:
	string lastName;
	string firstName;
	string ID;
public:
	Customer(string lastName = "", string firstName = "", string ID = "")
	{
		this->lastName = lastName;
		this->firstName = firstName;
		this->ID = ID;
	}

	void setlastName(string name1)
	{
		this->lastName = name1;
	}
	void setfirstName(string name2)
	{
		this->firstName = name2;
	}
	void setID(string numbers)
	{
		this->ID = numbers;
	}

	string getlastName()
	{
		return lastName;
	}
	string getfirstName()
	{
		return firstName;
	}
	string getID()
	{
		return ID; 
	}

	friend ostream& operator<<(ostream& os, const Customer &obj)
	{
		os << obj.lastName << ", " << obj.firstName << ", "
			<< obj.ID << endl;
		return os;
	}

	bool operator == (const Customer &a)
	{
		return this->ID == a.ID; 
	}

	Customer& operator = (const Customer &e) 
	{
		firstName = e.firstName;
		lastName = e.lastName;
		ID = e.ID;
		return *this;
	}
};


template<class T>
class Node {
public:
	T data;
	Node<T> *next;
	Node<T> *previous;

	Node() {
		next = NULL;
		previous = NULL;
	}
	Node(T _data) {
		this->data = _data;
		next = NULL;
		previous = nullptr;
	}
};

template<class T>
class List {
protected:
	Node<T> *head;
	Node<T> *tail;
	int count = 0;

public:

	List()
	{
		head = NULL; tail = NULL;
	}

	~List()
	{
		Node<T> *ptr = head;
		while (ptr) {
			Node<T> *old = ptr;
			ptr = ptr->next;
			delete old;
		}
	}

	void prepend(Node<T> *newNode) { insertAfter(nullptr, newNode); }
	void Append(Node<T> *newNode) { insertAfter(tail, newNode); }

	int get_count()
	{
		return count;
	}

	void insertAfter(Node<T>*curNode, Node<T>*newNode)
	{	

		Node<T>*sucNode; 

		if (head == NULL) {
			head = newNode;
			tail = newNode;
		}
		else if (curNode == tail) 
		{
			tail->next = newNode;
			newNode->previous = tail;
			tail = newNode;
		}
		else if (curNode == nullptr) 
		{
			newNode->next = head;      
			head->previous = newNode;  
			head = newNode;			 
		}
	
		else {
									
			sucNode = curNode->next;    
			newNode->next = sucNode;	 
			newNode->previous = curNode;  
			curNode->next = newNode;	   
			sucNode->previous = newNode; 
		}
		count++;
	}
	void remove(Node<T>*curNode)
	{
		Node<T>* sucNode, *predNode;
		sucNode = curNode->next;
		predNode = curNode->previous;
		if (sucNode != NULL) {
			sucNode->previous = predNode;
		}
		if (predNode != NULL)
		{
			predNode->next = sucNode;
		}
		if (curNode == head)
		{
			head = sucNode;
		}
		if (curNode == tail)
		{
			tail = predNode;
		}
		delete curNode;
		count--;
	}

	void search(string item)
	{
		Node<T> *ptr = head;
		while (ptr != NULL)
		{
			if (ptr->data == item)
				return true;
			ptr = ptr->next;
		}
		return false;
	}

	void display() {
		Node <T> * ptr;
		ptr = head;
		while (ptr != NULL) {
			cout << ptr->data << "\n";
			ptr = ptr->next;
		}
	}
};

template<class T>
class Vector {
private:
	//vSize = how many elements in array
	//maxSize = max size of array
	//if vSize > maxSize = allocate larger memory.
	int vSize, maxSize;
	T *Array;	 //points to allocated memory.
	//overloading operator.
	// T operator << ();

	void allocNew() //function to allocate new larger memory.
	{
		maxSize = vSize * 2; //by *2
		T *temp = new T[maxSize];
		for (int i = 0; i < vSize; i++)
		{
			temp[i] = Array[i];
		}
		delete[] Array;
		Array = temp;
	}
public:
	Vector() //constructor
	{
		maxSize = 10;
		Array = new T[maxSize];
		vSize = 0;
	}
	Vector(int i)//int is max size, how many elements to allocate. 
	{
		maxSize = i;
		Array = new T[maxSize];
		vSize = 0;
	}
	Vector(const Vector& v) // copy constructor
	{
		this->vSize = v.vSize;
		this->maxSize = v.maxSize;
		for (int i = 0; i < v.vSize; i++)
		{
			this->Array[i] = v.Array[i];
		}
	}
	~Vector()
	{
		delete[] Array;
	}
	void pushBack(T data) //pushes an element back of an array
	{
		if (vSize + 1 > maxSize)
		{
			allocNew(); //if vSize+1 > max size, call alloc
		}
		Array[vSize] = data;
		vSize++;
	}
	int size()	//returns the size
	{
		return vSize;
	}
	void resize(int size)
	{
		maxSize =size;
		T *temp = new T[maxSize];
		for (int i = 0; i < vSize; i++)
		{
			temp[i] = Array[i];
		}
		delete[] Array;
		Array = temp;
	}
	T& operator[](int i) //where to store the elements.
	{
		return Array[i];
		//throw "IndexOutOfRange";
	}
	int at(Vector<T> i)	//check if we want an existing element back.
	{
		return Array[i];
		throw "IndexOutOfRange";
	}
	int capacity()
	{
		return maxSize;
	}
	void insert(T dataInput)
	{
		pushBack(dataInput);
	}

}; 

template<class T>
class hashTable
{
private:
	Vector <List<T>> table;
	int collisions = 0;
public:
	hashTable(int s = 1)
	{
		table.resize(s);
	}
	int size()
	{
		return table.size();
	}
	int getCollisions()
	{
		return collisions;
	}

	int getHash(string key)
	{
		int sum = 0;
		for (int i = 0; i < key.length(); i++) sum += key[i];
		return hash_remainder(sum);
		//return hash_midSquare(sum);
		//return HashMultiplicative(key);
	}

	int hash_midSquare(int key)
	{
		int R = 15;
		
		int squaredKey = key * key;
		int lowBitsToRemove = (32 - R) / 2;
		long long int extractedBits = squaredKey >> lowBitsToRemove;
		extractedBits = extractedBits & (0xFFFFFFFF >> (32 - R));

		return extractedBits % table.capacity();
	}

	int HashMultiplicative(string key)
	{
		int stringHash = 5381;
		int HashMultiplier = 33;

		for (int i = 0; i < key.length(); i++)
		{
			stringHash = (stringHash * HashMultiplier) + key[i];
		}
		return abs(stringHash % table.capacity()); 
	}



	int hash_remainder(int key)
	{
		return key % table.capacity();
	}

	void HashInsert(T data)
	{	
		List<T> *bucketList = &table[getHash(data.getID())];
		if (bucketList->get_count() > 0) collisions++;
		Node<T> *node = new Node<T>(data);
		bucketList->prepend(node);
	} 

	void display()
	{
		for (int i = 0; i < table.capacity(); i++)
		{
			table[i].display();
		}
	}
}; 

int main()
{
	hashTable<Customer> table(999);
	ifstream myfile("Customer.csv");
	string lastName, firstName, ID;
	if (myfile.is_open())
	{
		while (!myfile.eof())
		{
			getline(myfile, lastName, ',');
			getline(myfile, firstName, ',');
			getline(myfile, ID, '\n');
			table.HashInsert(Customer(lastName, firstName, ID));
		}
		myfile.close();
	}
	table.display();
	cout << endl << table.getCollisions() << endl;
	system("pause");
	return 0;
}